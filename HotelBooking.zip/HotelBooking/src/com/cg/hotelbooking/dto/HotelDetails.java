package com.cg.hotelbooking.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="hoteldetails")
public class HotelDetails {

	@Id
	private int id;
	
	@Column(name="name")
	@NotEmpty(message="Hotel Name should not be empty")
	private String name;
	
	@Column(name="rating")
	private String rating;
	
	@Column(name="rate")
	private double rate;
	
	@Column(name="availablerooms")
	private int availableRooms;

	public HotelDetails() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	@Override
	public String toString() {
		return "HotelDetails [id=" + id + ", name=" + name + ", rating="
				+ rating + ", rate=" + rate + ", availableRooms="
				+ availableRooms + "]";
	}

	
}
