package com.cg.hotelbooking.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingdetails")
public class BookingDetails {

	@Id
	private int id;
	
	@Column(name="customername")
	private String customerName;
	
	@Column(name="hotelid")
	private int hotelId;
	
	@Column(name="todate")
	private Date toDate;
	
	@Column(name="fromdate")
	private Date fromDate;
	
	@Column(name="noofrooms")
	private int noofRooms;

	public BookingDetails() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public int getNoofRooms() {
		return noofRooms;
	}

	public void setNoofRooms(int noofRooms) {
		this.noofRooms = noofRooms;
	}

	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", customerName=" + customerName
				+ ", hotelId=" + hotelId + ", toDate=" + toDate + ", fromDate="
				+ fromDate + ", noofRooms=" + noofRooms + "]";
	}
	
	
}
