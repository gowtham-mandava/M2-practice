package com.cg.hotelbooking.dao;

import java.util.List;

import com.cg.hotelbooking.dto.HotelDetails;

public interface IBookingDAO {

	public List<HotelDetails> displayDetails();
}
