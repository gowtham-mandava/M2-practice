package com.cg.hotelbooking.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hotelbooking.dto.HotelDetails;

@Repository("bookingDAO")
public class BookingDAOImpl implements IBookingDAO {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<HotelDetails> displayDetails() {
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("FROM HotelDetails");
		List<HotelDetails> details=query.getResultList();	
		return details;
	}

	
	
	
}
