package com.cg.hotelbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hotelbooking.dto.HotelDetails;
import com.cg.hotelbooking.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService bookingService;
	
	@RequestMapping(value="all")
	public String getAll(){
		
		return "home";
	}
	
	@RequestMapping(value="hotelDetails",method=RequestMethod.GET)
	public ModelAndView showHotelDetails(){
		
		List<HotelDetails> details=bookingService.displayDetails();
		return new ModelAndView("hoteldetails", "model", details);
	}
	
	@RequestMapping(value="booking",method=RequestMethod.GET)
	public ModelAndView booking(@RequestParam("name") String name){
	
		return new ModelAndView("bookingconfirmation","model",name); 
	}
	
	
}
